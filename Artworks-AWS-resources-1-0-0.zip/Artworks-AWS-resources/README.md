# Cloud Load Balancing using Terraform

Quick way to provision an Apache and an Nginx webserver on two separate EC2 instances.
The servers are then assigned to an Application Load Balancer.
Traffic is automatically routed to the individual servers. 

